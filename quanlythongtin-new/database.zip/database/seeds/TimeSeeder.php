<?php

use Illuminate\Database\Seeder;

class TimeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('times')->insert([
            [
                'time_start' => '11:11:00',
                'time_end' => '23:11:00',
            ]
        ]);
    }
}

<?php

use Illuminate\Database\Seeder;

class RoomSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('rooms')->insert([
            [
                'name' => 'Phòng Deluxe Có Giường Cỡ King',
                'amount' => 2,
                'price' => '500000',
                'extensions' => 'Wifi, chỗ để xe, phòng tập gym',
                'note' => 'ghi chú',
                'time_id' => 1,
                'group_id' => 1
            ]
        ]);
    }
}

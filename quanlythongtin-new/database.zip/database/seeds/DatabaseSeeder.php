<?php

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     *
     * @return void
     */
    public function run()
    {
        $this->call([
            UserSeeder::class,
            PermissionSeeder::class,
            GroupSeeder::class,
            ExtensionsSeeder::class,
            RoomSeeder::class,
            TimeSeeder::class,
            BookingSeeder::class,
    ]);
    }
}

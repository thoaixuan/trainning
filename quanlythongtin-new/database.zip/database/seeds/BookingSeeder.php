<?php

use Illuminate\Database\Seeder;

class BookingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('bookings')->insert([
            [
                'date_start' => '2022-03-17',
                'date_end' => '2022-03-19',
                'room_id'=>1,
                'user_id'=>2,
                'name'=>'Book phòng test',
                'description'=>'Chưa có dữ liệu',
                'time_checkin'=>'11:11:00',
                'time_checkout'=>'11:12:00',
                'date_checkin'=>'2022-3-17',
                'date_checkout'=>'2022-3-18',
            ]
        ]);
    }
}
